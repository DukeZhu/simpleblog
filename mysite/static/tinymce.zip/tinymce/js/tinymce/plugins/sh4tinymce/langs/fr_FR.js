tinymce.addI18n('fr_FR',{
	'SH4TinyMCE - Code Editor'	: 'SH4TinyMCE - Editeur de code',
	'Insert/Edit Code'			: 'Ins\u00e9rer/Editer Code',
	'Language'					: 'Langage',
	'Auto links'				: 'Liens cliquables',
	'Gutter'					: 'Num\u00e9ros de lignes',
	'Html script'				: 'Script HTML',
	'Toolbar'					: 'Menu',
	'Highlight'					: 'Highlight',
	'Tab size'					: 'Tabulation',
	'First Line'				: '1\u00e8re ligne',
});
